There are 4 files in the folder.
1.fork.c
2.select.c
3.IMG_2120.jpg
4.makefile

Please use makefile to compile 2 .c files.
Use 'make clean' to remove the execution files.
